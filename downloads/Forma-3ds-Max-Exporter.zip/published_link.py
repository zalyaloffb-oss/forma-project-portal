"""Read the completed publisher receipt, never infer a link from a local export."""
import json,re
from pathlib import Path

def read_published_link(receipt):
    published=json.loads(Path(receipt).read_text(encoding='utf-8-sig'))
    project_id=published.get('projectId','')
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',project_id):
        raise ValueError('Некорректный идентификатор опубликованного проекта')
    expected='http://zalyaltn.beget.tech/catalog/viewer.html?project='+project_id
    value=published.get('viewerUrl','')
    if re.fullmatch(r'https://zalyaloffb-oss\.github\.io/forma-project-portal/[a-z0-9][a-z0-9-]{0,79}/',value):return value
    if value!=expected and not re.fullmatch(r'http://zalyaltn\.beget\.tech/[a-z0-9][a-z0-9-]{0,79}',value):
        raise ValueError('Публикация не вернула корректную ссылку на 3D')
    return value
