"""Classify this user's stand modules without merging their geometry."""
import hashlib,itertools,math
from collections import defaultdict

def classify(scene):
    factor={'inches':25.4,'feet':304.8,'millimeters':1,'centimeters':10,'meters':1000}[scene['systemUnit'].lower()]*scene['systemScale']
    entries=[]
    for obj in scene['nodes']:
        if not obj.get('positions') or obj.get('hidden') or obj.get('parent'):continue
        vertices=obj['positions']
        low=[min(p[i] for p in vertices) for i in range(3)];high=[max(p[i] for p in vertices) for i in range(3)]
        dimensions=[(high[i]-low[i])*factor for i in range(3)]
        ordered=sorted(dimensions)
        kind=None
        if abs(ordered[0]-16)<.05 and ordered[1]>80:kind='Закладная ЛДСП 16мм'
        # The supplied assembly uses detailed standard 120 mm modules, including rotated copies.
        elif abs(ordered[0]-120)<.05 and len(obj['faces']) in (1056,672):kind='Стандартный короб'
        elif abs(ordered[0]-120)<.05 and ordered[2]>=600 and ordered[1]<1500:kind='Доборный короб'
        if not kind:continue
        # Full vertex/triangle topology under proper axis rotations; 0.1 mm tolerance
        # accounts for float32 world coordinates, not a dimensional equivalence rule.
        centered=[[(p[i]-(low[i]+high[i])/2)*factor for i in range(3)] for p in vertices]
        signatures=[]
        for order in itertools.permutations(range(3)):
            parity=(-1)**sum(order[i]>order[j] for i in range(3) for j in range(i+1,3))
            for signs in itertools.product((-1,1),repeat=3):
                if parity*math.prod(signs)!=1:continue
                points=[tuple(round(p[order[k]]*signs[k]*10) for k in range(3)) for p in centered]
                triangles=sorted(tuple(sorted(points[v] for v in face)) for face in obj['faces'])
                signatures.append(hashlib.sha256(repr(triangles).encode()).hexdigest())
        signature=min(signatures)
        entries.append((obj,kind,ordered,signature))
    types=defaultdict(list)
    for entry in entries:types[(entry[1],entry[3])].append(entry)
    mapping={};report=[];names=defaultdict(int)
    def number(v):
        # Display source precision; remove only float32 noise within 0.02 mm of integers.
        if abs(v-round(v))<.02:return str(round(v))
        return ('%.2f'%v).rstrip('0').rstrip('.')
    for (kind,signature),members in types.items():
        dims=members[0][2];dimensions='х'.join(number(v) for v in (dims[2],dims[1],dims[0]))+'мм'
        base=kind+' '+dimensions;names[base]+=1
        variant='' if names[base]==1 else ' — вариант '+str(names[base])
        label=base+variant+' - '+str(len(members))+'шт'
        for index,(obj,_,_,_) in enumerate(members,1):
            mapping[obj['handle']]=[label,'Экземпляр '+str(index)]
        report.append({'component':label,'objects':[m[0]['name'] for m in members],'count':len(members),'shapeSignature':signature})
    return mapping,report
