import json, struct
from pathlib import Path
from pymxs import runtime as rt

out=Path(str(rt.formaExportFolder)) if rt.globalVars.isGlobal(rt.name('formaExportFolder')) else Path(__file__).parent/'kazanforum'
out.mkdir(exist_ok=True)
materials={}
rt.execute('global formaPublishedUrl = ""')

# Expand selected groups, retaining ancestor group nodes for the exported tree.
objects=list(rt.objects)
selected_only=rt.globalVars.isGlobal(rt.name('formaSelectedOnly')) and bool(rt.formaSelectedOnly)
included=None;ancestors=set()
explicit_handles=rt.globalVars.isGlobal(rt.name('formaObjectHandles')) and rt.formaObjectHandles is not None
if explicit_handles:
    included={int(handle) for handle in rt.formaObjectHandles}
    if not included:raise RuntimeError('Нет объектов для экспорта.')
elif selected_only:
    included={int(rt.getHandleByAnim(obj)) for obj in rt.selection}
    if not included:raise RuntimeError('Выберите объекты или группы для экспорта.')
    changed=True
    while changed:
        changed=False
        for obj in objects:
            handle=int(rt.getHandleByAnim(obj))
            if obj.parent and int(rt.getHandleByAnim(obj.parent)) in included and handle not in included:
                included.add(handle);changed=True
if included is not None:
    for obj in objects:
        if int(rt.getHandleByAnim(obj)) not in included:continue
        parent=obj.parent
        while parent:
            handle=int(rt.getHandleByAnim(parent))
            if handle in ancestors:break
            ancestors.add(handle);parent=parent.parent
def texture_info(value,depth=0):
    if value is None or depth>8:return None
    try:
        props=list(rt.getPropNames(value))
    except Exception:return None
    if str(rt.classOf(value))=='CoronaColor':
        try:
            if int(value.method)==3:
                hex_value=str(value.hexColor).lstrip('#')
                rgb=[int(hex_value[i:i+2],16)/255 for i in (0,2,4)]
                return {'color':[(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4)*float(value.multiplier) for c in rgb]}
            if int(value.method)==1:
                return {'color':[float(c)*float(value.multiplier) for c in value.colorHdr]}
            color=value.color
            return {'color':[float(c)/255*float(value.multiplier) for c in (color.r,color.g,color.b)]}
        except Exception:pass
    for prop in props:
        if str(prop).lower() in ('filename','file','mapname'):
            try:
                filename=str(rt.getProperty(value,prop))
                if filename and Path(filename).is_file():return {'bitmap':filename}
            except Exception:pass
    for prop in props:
        if any(word in str(prop).lower() for word in ('map','texture','input')):
            try:
                nested=texture_info(rt.getProperty(value,prop),depth+1)
                if nested:return nested
            except Exception:pass
    if rt.isProperty(value,'baseColor'):
        try:
            color=rt.getProperty(value,rt.name('baseColor'))
            return {'color':[float(color.r)/255,float(color.g)/255,float(color.b)/255]}
        except Exception:pass
    return None
def material_info(material):
    if material is None:return None
    key=str(rt.getHandleByAnim(material))
    if key in materials:return key
    info={'name':str(material.name),'class':str(rt.classOf(material)),'properties':{}}
    materials[key]=info
    for prop in rt.getPropNames(material):
        name=str(prop)
        try:
            value=rt.getProperty(material,prop)
            if isinstance(value,(str,int,float,bool)):info['properties'][name]=value
            elif str(rt.classOf(value))=='Color':info['properties'][name]=[float(value.r)/255,float(value.g)/255,float(value.b)/255]
            elif value is not None:
                texture=texture_info(value)
                if texture:info['properties'][name]=texture
        except Exception:pass
    if str(rt.classOf(material))=='Multimaterial':
        info['children']=[material_info(m) for m in material.materialList]
    return key

nodes=[]
for obj in objects:
    handle=int(rt.getHandleByAnim(obj))
    if included is not None and handle not in included and not (handle in ancestors and str(rt.classOf(obj))=='Dummy'):continue
    info={'handle':int(rt.getHandleByAnim(obj)),'name':str(obj.name),'class':str(rt.classOf(obj)),
          'parent':int(rt.getHandleByAnim(obj.parent)) if obj.parent else None,
          'hidden':bool(obj.isHidden),'wireColor':[float(obj.wireColor.r)/255,float(obj.wireColor.g)/255,float(obj.wireColor.b)/255]}
    try:
        if str(rt.superClassOf(obj))!='GeometryClass' and str(rt.classOf(obj))!='Editable_Poly':
            if str(rt.classOf(obj))=='Dummy':nodes.append(info)
            continue
        mesh=rt.snapshotAsMesh(obj)
        positions=[]
        for i in range(1,int(rt.getNumVerts(mesh))+1):
            # snapshotAsMesh already returns world-space vertices.
            p=rt.getVert(mesh,i)
            positions.append([float(p.x),float(p.y),float(p.z)])
        faces=[];material_ids=[]
        for i in range(1,int(rt.getNumFaces(mesh))+1):
            face=rt.getFace(mesh,i);faces.append([int(face.x)-1,int(face.y)-1,int(face.z)-1]);material_ids.append(int(rt.getFaceMatID(mesh,i)))
        if not faces:continue
        uvs=[];uvfaces=[]
        if rt.meshop.getMapSupport(mesh,1):
            for i in range(1,int(rt.meshop.getNumMapVerts(mesh,1))+1):
                p=rt.meshop.getMapVert(mesh,1,i);uvs.append([float(p.x),1-float(p.y)])
            for i in range(1,len(faces)+1):
                p=rt.meshop.getMapFace(mesh,1,i);uvfaces.append([int(p.x)-1,int(p.y)-1,int(p.z)-1])
        info.update(positions=positions,faces=faces,material_ids=material_ids,uvs=uvs,uvfaces=uvfaces,material=material_info(obj.material))
        rt.delete(mesh)
    except Exception as error:
        info['error']=str(error)
    nodes.append(info)
report={'nodes':nodes,'materials':materials,'systemUnit':str(rt.units.SystemType),'systemScale':float(rt.units.SystemScale)}
(out/'scene.json').write_text(json.dumps(report,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print('FORMA_GEOMETRY_EXTRACTED',len(nodes),len(materials))
if rt.globalVars.isGlobal(rt.name('formaProjectName')):
    import sys
    sys.path.insert(0,str(Path(__file__).parent))
    from build_glb import build
    build(out/'scene.json',out/'model.glb',str(rt.formaProjectName))
    if not rt.maxOps.isInNonInteractiveMode():
        try:
            preview=rt.gw.getViewportDib();preview.filename=str(out/'cover.png');rt.save(preview);rt.close(preview)
        except Exception as error:print('Preview unavailable:',str(error))
    from web_bundle import create_bundle
    bundle=create_bundle(out,str(rt.formaProjectName),str(rt.maxFilePath)+str(rt.maxFileName) if rt.maxFileName else None)
    rt.execute('global formaWebBundle')
    rt.formaWebBundle=str(bundle)
    if rt.globalVars.isGlobal(rt.name('formaPublishToSite')) and rt.formaPublishToSite:
        import subprocess,shutil
        pwsh=shutil.which('pwsh')
        if not pwsh:
            bundled=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
            if bundled.is_file():pwsh=str(bundled)
        if not pwsh:raise RuntimeError('Для отправки в каталог требуется PowerShell 7')
        subprocess.run([pwsh,'-NoProfile','-File',str(Path(__file__).parent/'publish_project.ps1'),
                        '-ProjectFolder',str(out),'-ProjectTitle',str(rt.formaProjectName),
                        '-SourceMax',str(rt.maxFilePath)+str(rt.maxFileName)],check=True)
        from published_link import read_published_link
        rt.formaPublishedUrl=read_published_link(out/'published.json')
