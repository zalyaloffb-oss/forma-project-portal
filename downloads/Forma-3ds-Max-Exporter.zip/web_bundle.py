import hashlib,json,re,zipfile
from pathlib import Path

def create_bundle(folder,title,source_max=None):
    folder=Path(folder);name=re.sub(r'[<>:"/\\|?*]', '_',title).strip(' .') or 'Проект'
    destination=folder/(name+'.forma.zip')
    manifest={'version':1,'title':title,'sourceFileName':Path(source_max).name if source_max else '',
              'sceneSha256':hashlib.sha256((folder/'scene.json').read_bytes()).hexdigest(),
              'modelSha256':hashlib.sha256((folder/'model.glb').read_bytes()).hexdigest()}
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False))
        for filename in ('model.glb','scene.json','cover.png'):
            if filename=='cover.png' and (folder/filename).exists() and not (folder/filename).read_bytes().startswith(b'\x89PNG\r\n\x1a\n'):continue
            if (folder/filename).is_file():archive.write(folder/filename,filename)
        if source_max and Path(source_max).is_file():archive.write(source_max,'source.max')
    return destination
