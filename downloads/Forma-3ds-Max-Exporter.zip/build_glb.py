import json,struct,math,mimetypes
from pathlib import Path
from collections import defaultdict
from classify_components import classify

def build(source,destination,title):
    scene=json.loads(Path(source).read_text(encoding='utf-8'))
    unit={'inches':.0254,'feet':.3048,'millimeters':.001,'centimeters':.01,'meters':1.0}.get(scene['systemUnit'].lower())
    if unit is None:raise ValueError('Unsupported scene units: '+scene['systemUnit'])
    unit*=scene['systemScale']
    component_paths,component_report=classify(scene)
    blob=bytearray()
    gltf={'asset':{'version':'2.0','generator':'Forma 3ds Max Exporter'},'scene':0,'scenes':[{'nodes':[0]}],
          'nodes':[{'name':title,'children':[],'extras':{'sourceApp':'3ds Max','units':'meters'}}],
          'meshes':[],'materials':[],'buffers':[],'bufferViews':[],'accessors':[],'images':[],'textures':[],
          'samplers':[{'wrapS':10497,'wrapT':10497}]}
    # Use the large ground panel as a framing anchor; this scene also contains
    # a reference assembly tens of metres away, which must remain untouched.
    floors=[]
    for obj in scene['nodes']:
        if not obj.get('positions') or obj.get('hidden'):continue
        lo=[min(v[i] for v in obj['positions'])*unit for i in range(3)]
        hi=[max(v[i] for v in obj['positions'])*unit for i in range(3)]
        if hi[2]-lo[2]<.03 and (hi[0]-lo[0])*(hi[1]-lo[1])>10:floors.append((obj,lo,hi))
    if floors:
        _,lo,hi=max(floors,key=lambda f:(f[2][0]-f[1][0])*(f[2][1]-f[1][1]))
        nearby=[p for obj in scene['nodes'] if not obj.get('hidden') for p in obj.get('positions',[]) if lo[0]-1<=p[0]*unit<=hi[0]+1 and lo[1]-1<=p[1]*unit<=hi[1]+1]
        bottom=min(p[2]*unit for p in nearby);top=max(p[2]*unit for p in nearby)
        mid=[(lo[i]+hi[i])/2 for i in range(3)];width=max(hi[0]-lo[0],hi[1]-lo[1]);target=[mid[0],(bottom+top)/2,-mid[1]]
        horizontal=math.sqrt(2);view_length=math.sqrt(2+.65**2)
        up=(-.65/(horizontal*view_length),horizontal/view_length,.65/(horizontal*view_length))
        target_projection=mid[0]*up[0]+target[1]*up[1]+mid[1]*up[2]
        framed_height=2.2*max(abs(sum(p[i]*unit*up[j] for i,j in ((0,0),(2,1),(1,2)))-target_projection) for p in nearby)
        gltf['nodes'][0]['extras']['fusionCamera']={'orthographic':True,'height':max(5,framed_height),
             'target':target,'eye':[target[0]+width,target[1]+width*.65,target[2]+width],'up':[0,1,0]}
    warnings=[];textures={};material_indices={}
    def buffer(data,target=None):
        while len(blob)%4:blob.append(0)
        index=len(gltf['bufferViews']);view={'buffer':0,'byteOffset':len(blob),'byteLength':len(data)}
        if target:view['target']=target
        gltf['bufferViews'].append(view);blob.extend(data);return index
    def accessor(values,width,kind,positions=False):
        packed=struct.pack('<'+'f'*len(values),*values)
        a={'bufferView':buffer(packed,34962),'componentType':5126,'count':len(values)//width,'type':kind}
        if positions:
            a['min']=[min(values[i::width]) for i in range(width)];a['max']=[max(values[i::width]) for i in range(width)]
        gltf['accessors'].append(a);return len(gltf['accessors'])-1
    def material(key,fallback):
        cache=key or str(fallback)
        if cache in material_indices:return material_indices[cache]
        src=scene['materials'].get(key,{})
        props=src.get('properties',{})
        color=props.get('colorDiffuse',props.get('diffuse',props.get('base_color',fallback)))
        if not isinstance(color,list):color=fallback
        diffuse_map=props.get('texmapDiffuse',{})
        if isinstance(diffuse_map,dict) and diffuse_map.get('color'):color=diffuse_map['color']
        opacity=props.get('levelOpacity',1.0)
        pbr={'baseColorFactor':[*[max(0,min(1,float(c))) for c in color[:3]],float(opacity)],'metallicFactor':0,'roughnessFactor':.8}
        result={'name':src.get('name','Object colour'),'pbrMetallicRoughness':pbr,'doubleSided':True}
        map_names=('texmapDiffuse','diffuseMap','base_color_map','baseColorMap')
        if src.get('class')=='CoronaLightMtl':map_names+=('texmap',)
        for name in map_names:
            tex=props.get(name)
            if not isinstance(tex,dict) or not tex.get('bitmap'):continue
            filename=tex['bitmap'];path=Path(filename)
            mime=mimetypes.guess_type(filename)[0]
            if mime not in ('image/jpeg','image/png'):
                warnings.append('Unsupported texture: '+filename);break
            if filename not in textures:
                view=buffer(path.read_bytes());gltf['images'].append({'bufferView':view,'mimeType':mime,'name':path.name})
                gltf['textures'].append({'sampler':0,'source':len(gltf['images'])-1});textures[filename]=len(gltf['textures'])-1
            pbr['baseColorTexture']={'index':textures[filename]};pbr['baseColorFactor']=[1,1,1,float(opacity)];break
        if opacity<.999:result['alphaMode']='BLEND'
        index=len(gltf['materials']);gltf['materials'].append(result);material_indices[cache]=index;return index
    originals={n['handle']:n for n in scene['nodes']}
    groups={():0}
    def group(path):
        if path not in groups:
            parent=group(path[:-1]);groups[path]=len(gltf['nodes']);gltf['nodes'].append({'name':path[-1],'children':[]});gltf['nodes'][parent]['children'].append(groups[path])
        return groups[path]
    total=0
    for obj in scene['nodes']:
        if not obj.get('faces') or obj.get('hidden'):continue
        path=[];parent=obj.get('parent');seen=set()
        while parent in originals and parent not in seen:
            seen.add(parent);node=originals[parent];path.insert(0,node['name']);parent=node.get('parent')
        if obj['handle'] in component_paths:path=component_paths[obj['handle']]
        else:path.append(obj['name'])
        parent_node=group(tuple(path))
        faces=obj['faces'];verts=obj['positions'];uvs=obj.get('uvs',[]);uvfaces=obj.get('uvfaces',[])
        # Separate disconnected mesh elements while keeping them inside their component.
        roots=list(range(len(verts)))
        def root(i):
            while roots[i]!=i:roots[i]=roots[roots[i]];i=roots[i]
            return i
        # Weld coincident positions for topology only; UV seams remain intact in export.
        points={}
        for i,v in enumerate(verts):
            point=tuple(round(x,5) for x in v)
            if point in points:roots[root(i)]=root(points[point])
            else:points[point]=i
        for a,b,c in faces:roots[root(b)]=root(a);roots[root(c)]=root(a)
        elements=defaultdict(list)
        for fi,f in enumerate(faces):elements[root(f[0])].append(fi)
        for element_no,face_indices in enumerate(elements.values(),1):
            by_material=defaultdict(list)
            for fi in face_indices:by_material[obj['material_ids'][fi]].append(fi)
            primitives=[]
            for mat_id,indices in by_material.items():
                positions=[];normals=[];texcoords=[]
                for fi in indices:
                    triangle=[]
                    for vi in faces[fi]:
                        x,y,z=verts[vi];triangle.append((x*unit,z*unit,-y*unit))
                    a,b,c=triangle;ab=[b[k]-a[k] for k in range(3)];ac=[c[k]-a[k] for k in range(3)]
                    normal=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
                    length=math.sqrt(sum(v*v for v in normal))
                    if length<1e-14:continue
                    normal=[v/length for v in normal]
                    for corner,point in enumerate(triangle):
                        positions.extend(point);normals.extend(normal)
                        if uvfaces:texcoords.extend(uvs[uvfaces[fi][corner]])
                if not positions:continue
                attrs={'POSITION':accessor(positions,3,'VEC3',True),'NORMAL':accessor(normals,3,'VEC3')}
                if texcoords:attrs['TEXCOORD_0']=accessor(texcoords,2,'VEC2')
                key=obj.get('material');src=scene['materials'].get(key,{})
                if src.get('children'):key=src['children'][(mat_id-1)%len(src['children'])]
                primitives.append({'attributes':attrs,'material':material(key,obj['wireColor']),'mode':4})
            if not primitives:continue
            mesh=len(gltf['meshes']);gltf['meshes'].append({'name':obj['name'],'primitives':primitives})
            body_name=obj['name'] if len(elements)==1 else 'Деталь '+str(element_no)
            extras={'bodyName':body_name,'fusionPath':'+'.join(path),'maxObjectHandle':obj['handle'],'sourceApp':'3ds Max'}
            gltf['meshes'][mesh]['extras']=extras
            node=len(gltf['nodes']);gltf['nodes'].append({'name':body_name,'mesh':mesh,'extras':extras});gltf['nodes'][parent_node]['children'].append(node);total+=1
    if not total:raise ValueError('Scene has no exported geometry')
    if not gltf['images']:
        del gltf['images'];del gltf['textures'];del gltf['samplers']
    while len(blob)%4:blob.append(0)
    gltf['buffers']=[{'byteLength':len(blob)}]
    encoded=json.dumps(gltf,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    encoded+=b' '*((-len(encoded))%4)
    output=struct.pack('<4sII',b'glTF',2,28+len(encoded)+len(blob))+struct.pack('<I4s',len(encoded),b'JSON')+encoded+struct.pack('<I4s',len(blob),b'BIN\0')+blob
    Path(destination).write_bytes(output)
    report={'title':title,'objects':len(scene['nodes']),'bodies':total,'textures':len(textures),'bytes':len(output),'warnings':warnings,'components':component_report}
    Path(destination).with_suffix('.report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))
    return report

if __name__=='__main__':
    import sys
    build(sys.argv[1],sys.argv[2],sys.argv[3])
