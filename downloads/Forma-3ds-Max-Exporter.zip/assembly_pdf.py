"""Generate an assembly drawing from exported Max geometry; no invented electrical data."""
import argparse,json,math,io,hashlib
from pathlib import Path
from datetime import datetime
import numpy as np
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from classify_components import classify

W,H=841.89,595.28
FONT=next((p for p in (Path('C:/Windows/Fonts/arial.ttf'),Path(__file__).parent/'fonts/DejaVuSans.ttf',Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')) if p.is_file()),None)
BOLD=next((p for p in (Path('C:/Windows/Fonts/arialbd.ttf'),Path(__file__).parent/'fonts/DejaVuSans-Bold.ttf',Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')) if p.is_file()),None)
def fmt(x):
    # The model's nominal sizes may have float32 noise; show 0.1 mm precision.
    v=round(float(x),1)
    return f'{v:g}'

def load(source):
    raw=Path(source).read_bytes();s=json.loads(raw)
    factor={'inches':25.4,'feet':304.8,'millimeters':1,'centimeters':10,'meters':1000}[s['systemUnit'].lower()]*s['systemScale']
    paths,types=classify(s);objects=[]
    for n in s['nodes']:
        if not n.get('faces') or n.get('hidden'):continue
        v=np.asarray(n['positions'])*factor;f=np.asarray(n['faces'],dtype=int)
        lo=v.min(0);hi=v.max(0);dims=hi-lo
        props=s['materials'].get(n.get('material'),{}).get('properties',{})
        color=props.get('colorDiffuse',props.get('diffuse',n['wireColor']))
        if not isinstance(color,list):color=n['wireColor']
        if isinstance(props.get('texmapDiffuse'),dict) and props['texmapDiffuse'].get('color'):color=props['texmapDiffuse']['color']
        color=np.asarray(color[:3])
        if np.max(color)<.22:color=np.array([.84,.84,.84])
        else:color=.75*color+.25*np.ones(3)
        objects.append(dict(name=n['name'],handle=n['handle'],v=v,f=f,lo=lo,hi=hi,dims=dims,center=(lo+hi)/2,color=color,path=paths.get(n['handle'])))
    if not objects:raise ValueError('No geometry')
    return s,objects,types,hashlib.sha256(raw).hexdigest()

def render(objects,U,V,D,pixels=1600):
    U=np.array(U);V=np.array(V);D=np.array(D)
    allv=np.concatenate([o['v'] for o in objects]);xy=np.column_stack((allv@U,allv@V))
    low=xy.min(0);high=xy.max(0);span=np.maximum(high-low,1)
    scale=pixels/max(span);width=int(span[0]*scale)+12;height=int(span[1]*scale)+12
    depth=np.full((height,width),-np.inf);rgb=np.full((height,width,3),255,dtype=np.uint8)
    projected=[]
    for o in objects:
        v=o['v'];p=np.column_stack(((v@U-low[0])*scale+6,(high[1]-v@V)*scale+6,v@D))
        projected.append((o,p))
        color=np.clip(o['color']*255,0,255)
        for face in o['f']:
            tri=p[face];a,b,c=tri
            den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
            if abs(den)<1e-7:continue
            x0=max(0,int(np.floor(tri[:,0].min())));x1=min(width-1,int(np.ceil(tri[:,0].max())))
            y0=max(0,int(np.floor(tri[:,1].min())));y1=min(height-1,int(np.ceil(tri[:,1].max())))
            yy,xx=np.mgrid[y0:y1+1,x0:x1+1];xx=xx+.5;yy=yy+.5
            aa=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/den
            bb=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/den;cc=1-aa-bb
            z=aa*a[2]+bb*b[2]+cc*c[2];buffer=depth[y0:y1+1,x0:x1+1]
            mask=(aa>=-1e-6)&(bb>=-1e-6)&(cc>=-1e-6)&(z>buffer)
            normal=np.cross(v[face[1]]-v[face[0]],v[face[2]]-v[face[0]]);length=np.linalg.norm(normal)
            shade=.83+.17*abs(normal@D)/length if length else 1
            buffer[mask]=z[mask];rgb[y0:y1+1,x0:x1+1][mask]=np.clip(color*shade,0,255).astype(np.uint8)
    # Edges across sharp faces only; depth-test to avoid hidden lines and triangulation.
    for o,p in projected:
        edges={};v=o['v'];pointkeys=[tuple(np.round(q,3)) for q in v]
        for face in o['f']:
            normal=np.cross(v[face[1]]-v[face[0]],v[face[2]]-v[face[0]]);length=np.linalg.norm(normal)
            if length<1e-8:continue
            normal=normal/length
            for a,b in zip(face,np.roll(face,-1)):
                key=tuple(sorted((pointkeys[a],pointkeys[b])));edges.setdefault(key,[]).append((int(a),int(b),normal))
        for values in edges.values():
            if len(values)>1 and all(abs(values[0][2]@e[2])>.98 for e in values[1:]):continue
            a,b,_=values[0];a=p[a];b=p[b];count=max(2,int(np.linalg.norm(b[:2]-a[:2])*1.5))
            points=a+(b-a)*np.linspace(0,1,count)[:,None];ix=np.clip(np.rint(points[:,0]).astype(int),0,width-1);iy=np.clip(np.rint(points[:,1]).astype(int),0,height-1)
            for dx,dy in ((0,0),(1,0),(0,1)):
                x=np.clip(ix+dx,0,width-1);y=np.clip(iy+dy,0,height-1)
                visible=points[:,2]>=depth[y,x]-max(2,2/scale)
                rgb[y[visible],x[visible]]=30
    return Image.fromarray(rgb),low,high

class Drawing:
    def __init__(self,out,title,sourcehash,total=5):
        if FONT is None or BOLD is None:raise RuntimeError('PDF fonts missing')
        pdfmetrics.registerFont(TTFont('Drawing',str(FONT)));pdfmetrics.registerFont(TTFont('DrawingBold',str(BOLD)))
        self.c=canvas.Canvas(str(out),pagesize=(W,H));self.c.setTitle(title+' | Монтажный чертёж');self.title=title;self.page=0;self.hash=sourcehash;self.total=total
    def text(self,x,y,text,size=9,bold=False):
        self.c.setFillColor(HexColor('#25342e'));self.c.setFont('DrawingBold' if bold else 'Drawing',size);self.c.drawString(x,y,str(text))
    def start(self,label):
        self.page+=1;self.label=label
        # Keep all drawing content above the original-style bottom-right stamp.
        self.c.saveState();self.c.translate(26,55);self.c.scale(.97,.87)
    def view(self,objects,U,V,D,rect):
        im,low,high=render(objects,U,V,D);x,y,w,h=rect
        factor=min(w/(high[0]-low[0]+1),h/(high[1]-low[1]+1))
        width=(high[0]-low[0])*factor;height=(high[1]-low[1])*factor
        x+=(w-width)/2;y+=(h-height)/2
        self.c.drawImage(ImageReader(im),x,y,width,height,mask='auto')
        def xy(point):return x+(np.dot(point,U)-low[0])*factor,y+(np.dot(point,V)-low[1])*factor
        return xy,(x,y,width,height),factor
    def dim(self,a,b,offset,label=None,vertical=False):
        c=self.c;c.setStrokeColor(HexColor('#434e47'));c.setFillColor(HexColor('#434e47'));c.setLineWidth(.5)
        if vertical:
            x=offset;c.line(a[0],a[1],x-3,a[1]);c.line(b[0],b[1],x-3,b[1]);c.line(x,a[1],x,b[1]);p=(x,(a[1]+b[1])/2)
            for y in (a[1],b[1]):c.line(x-2,y-2,x+2,y+2)
            c.saveState();c.translate(x-5,p[1]);c.rotate(90);c.setFont('Drawing',8);c.drawCentredString(0,0,str(label));c.restoreState()
        else:
            y=offset;c.line(a[0],a[1],a[0],y+3);c.line(b[0],b[1],b[0],y+3);c.line(a[0],y,b[0],y)
            for x in (a[0],b[0]):c.line(x-2,y-2,x+2,y+2)
            c.setFont('Drawing',8);c.drawCentredString((a[0]+b[0])/2,y+4,str(label))
    def balloon(self,p,label):
        c=self.c;c.setFillColor(HexColor('#FFFFFF'));c.setStrokeColor(HexColor('#344d40'));c.circle(*p,8,fill=1,stroke=1)
        c.setFont('DrawingBold',9);c.setFillColor(HexColor('#25342e'));c.drawCentredString(p[0],p[1]-3,str(label))
    def stamp_text(self,x,y,w,h,text,size=9,bold=False):
        c=self.c;font='DrawingBold' if bold else 'Drawing'
        while pdfmetrics.stringWidth(text,font,size)>w-6 and size>5:size-=.25
        c.setFillColor(HexColor('#000000'));c.setFont(font,size);c.drawCentredString(x+w/2,y+(h-size)/2+2,text)
    def end(self):
        self.c.restoreState();c=self.c;c.setStrokeColor(HexColor('#000000'));c.setLineWidth(.85)
        c.rect(7.5,12,W-15,H-24);c.rect(44,20,W-58,H-40)
        x,y=415,20;a,b,r=145,166,W-14-415-145-166;h=70
        c.setLineWidth(1);c.rect(x,y,a+b+r,h)
        for xx in (x+a,x+a+b):c.line(xx,y,xx,y+h)
        c.line(x+a,y+35,x+a+b+r,y+35)
        # Author/check/accept table; retain original fields without false attribution.
        cols=[0,44,89,122,145]
        for dx in cols[1:-1]:c.line(x+dx,y,x+dx,y+58)
        for dy in (15,30,45,58):c.line(x,y+dy,x+a,y+dy)
        self.stamp_text(x+89,y+45,33,13,'Подп.',7);self.stamp_text(x+122,y+45,23,13,'Дата',7)
        for name,dy in [('Разработал',30),('Проверил',15),('Принял',0)]:self.stamp_text(x,y+dy,44,15,name,7)
        self.stamp_text(x+122,y+30,23,15,datetime.now().strftime('%d.%m.%y'),5)
        project='Стенд ФПП 3' if self.title.startswith('ФПП 3') else self.title
        self.stamp_text(x+a,y+35,b,35,project,10)
        label={'Развёртки стен':'Стены','Монтажные размеры и границы комплекта':'Монтажные примечания'}.get(self.label,self.label)
        self.stamp_text(x+a,y,b,35,label,9)
        rx=x+a+b
        c.line(rx,y+46,rx+r,y+46);c.line(rx,y+58,rx+r,y+58);c.line(rx+r/2,y+35,rx+r/2,y+58)
        self.stamp_text(rx,y+46,r/2,12,'Лист',7);self.stamp_text(rx+r/2,y+46,r/2,12,'Листов',7)
        self.stamp_text(rx,y+35,r/2,11,str(self.page),8);self.stamp_text(rx+r/2,y+35,r/2,11,str(self.total),8)
        self.stamp_text(rx,y,r,35,'ИВЕНТЭКСПОСЕРВИС',8,True)
        self.c.showPage()

def generate(source,out,title):
    s,objects,types,sourcehash=load(source);out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    rows=[];positions={}
    def type_order(group):
        o=next(o for o in objects if o['name'] in group['objects']);dims=sorted(o['dims'])
        return (0 if group['component'].startswith('Стандартный') else 1,-dims[-1]*dims[-2])
    for group in sorted(types,key=type_order):
        obs=[o for o in objects if o['name'] in group['objects']]
        if not obs:continue
        label=group['component'].rsplit(' - ',1)[0];position=len(rows)+1
        rows.append((position,label,len(obs)));positions.update({o['handle']:position for o in obs})
    rest={}
    for o in objects:
        if o['handle'] in positions:continue
        dims=tuple(sorted((round(x,1) for x in o['dims']),reverse=True))
        if dims[0]>2000 and dims[-1]<1:kind='Площадка (условная модель)'
        elif dims[-1]<40:kind='Профиль / деталь'
        else:kind='Отдельное изделие'
        rest.setdefault((kind,dims),[]).append(o)
    for (kind,dims),obs in rest.items():
        p=len(rows)+1;rows.append((p,kind+' '+'х'.join(fmt(x) for x in dims)+'мм',len(obs)));positions.update({o['handle']:p for o in obs})
    # Detect axis-aligned wall planes from actual 120 mm modules, not scene names.
    wallgroups={}
    for o in objects:
        if not o.get('path'):continue
        axis=int(np.argmin(o['dims']))
        if axis==2 or abs(o['dims'][axis]-120)>.1:continue
        key=(axis,round(o['center'][axis],1));wallgroups.setdefault(key,[]).append(o)
    # Number clockwise by anchor location: upper horizontal, lower horizontal,
    # then left and right vertical planes. The labels belong to this PDF.
    walls=sorted(wallgroups.items(),key=lambda kv:(0 if kv[0][0]==1 else 1,-kv[0][1] if kv[0][0]==1 else kv[0][1]))
    total=3+math.ceil(max(0,len(rows)-8)/12)+(math.ceil(len(walls)/2) if walls else 2)
    d=Drawing(out,title,sourcehash,total)
    d.start('Общий вид');U=np.array([1,1,0])/math.sqrt(2);D=np.array([1,-1,.8]);D=D/np.linalg.norm(D);V=np.cross(D,U)
    d.view(objects,U,V,D,(45,85,660,420));d.text(700,484,'Состав:',10,True)
    d.text(700,463,f'{len(objects)} объектов',9);d.text(700,445,f'{len(walls)} плоскости стен',9)
    d.text(700,415,'Группы и размеры',9);d.text(700,399,'из исходной модели.',9)
    d.text(700,371,'Цвет - ориентир,',9);d.text(700,355,'не марка материала.',9)
    d.end()
    d.start('План и спецификация')
    xy,b,scale=d.view(objects,[1,0,0],[0,1,0],[0,0,1],(70,107,395,375))
    allv=np.concatenate([o['v'] for o in objects]);lo=allv.min(0);hi=allv.max(0)
    d.dim(xy([lo[0],lo[1],0]),xy([hi[0],lo[1],0]),87,fmt(hi[0]-lo[0]));d.dim(xy(lo),xy([lo[0],hi[1],0]),48,fmt(hi[1]-lo[1]),True)
    for number,(key,obs) in enumerate(walls,1):
        axis,_=key;center=np.mean([o['center'] for o in obs],0);p=xy(center)
        sign=1 if center[axis]>(lo[axis]+hi[axis])/2 else -1
        d.balloon((p[0]-15*sign if axis==0 else p[0],p[1]+15 if axis==1 else p[1]),number)
        vertices=np.concatenate([o['v'] for o in obs]);wl=vertices.min(0);wh=vertices.max(0)
        if axis==1:
            d.dim(xy([wl[0],center[1],0]),xy([wh[0],center[1],0]),p[1]+sign*22,fmt(wh[0]-wl[0]))
            cornerlo=wl[0];cornerhi=wh[0]
            for otherkey,others in walls:
                if otherkey[0]!=0:continue
                ov=np.concatenate([o['v'] for o in others]);ol=ov.min(0);oh=ov.max(0)
                if oh[1]<wl[1]-.2 or ol[1]>wh[1]+.2 or oh[0]<wl[0]-.2 or ol[0]>wh[0]+.2:continue
                cornerlo=min(cornerlo,ol[0]);cornerhi=max(cornerhi,oh[0])
            if cornerhi-cornerlo>wh[0]-wl[0]+1:d.dim(xy([cornerlo,center[1],0]),xy([cornerhi,center[1],0]),p[1]+sign*37,fmt(cornerhi-cornerlo))
        else:d.dim(xy([center[0],wl[1],0]),xy([center[0],wh[1],0]),p[0]+sign*22,fmt(wh[1]-wl[1]),True)
    horizontal=[obs for key,obs in walls if key[0]==1]
    if len(horizontal)==2:
        bounds=[(np.concatenate([o['v'] for o in obs]).min(0),np.concatenate([o['v'] for o in obs]).max(0)) for obs in horizontal]
        lower,upper=sorted(bounds,key=lambda b:b[0][1]);xlo=max(lower[0][0],upper[0][0]);xhi=min(lower[1][0],upper[1][0])
        if xhi>xlo and upper[0][1]>lower[1][1]:
            x=(xlo+xhi)/2;a=xy([x,lower[1][1],0]);bpt=xy([x,upper[0][1],0]);d.dim(a,bpt,a[0],fmt(upper[0][1]-lower[1][1]),True)
    tx=491;y=494;d.text(tx,y,'Поз.',10,True);d.text(tx+28,y,'Элемент / габарит',10,True);d.text(786,y,'Кол.',10,True);y-=21
    for p,label,count in rows[:8]:
        d.text(tx,y,str(p),9);parts=label.rsplit(' ',1)
        d.text(tx+28,y,parts[0][:42],8.5);d.text(tx+28,y-13,parts[-1],8.5);d.text(791,y,count,9);y-=35
    for text in ('Номера в кружках - стены данного комплекта.','Материал, крепёж и обшивка не заданы в MAX.','Закладная 16 мм в модели не обнаружена.' if not any('Закладная' in row[1] for row in rows) else 'Закладные учтены по геометрии.','Количество - исходные изделия, не треугольники.'):
        d.text(tx,y-8,text,7.5);y-=17
    d.end()
    for start in range(8,len(rows),12):
        d.start('Спецификация - продолжение');y=488
        for p,label,count in rows[start:start+12]:
            d.text(46,y,p,10);d.text(82,y,label,10);d.text(763,y,count,10);y-=30
        d.end()
    for start in range(0,len(walls),2):
        d.start('Развёртки стен')
        for column,(key,obs) in enumerate(walls[start:start+2]):
            axis,_=key;U=[1,0,0] if axis==1 else [0,1,0];V=[0,0,1];D=[0,-1,0] if axis==1 else [-1,0,0]
            left=column*398+53;number=start+column+1;d.text(left,494,'Стена '+str(number),13,True)
            xy,b,scale=d.view(obs,U,V,D,(left+25,125,290,325))
            vertices=np.concatenate([o['v'] for o in obs]);lo=vertices.min(0);hi=vertices.max(0);u=0 if axis==1 else 1
            a=lo.copy();a[2]=0;bpt=hi.copy();bpt[2]=0
            d.dim(xy(a),xy(bpt),104,fmt(hi[u]-lo[u]));a=lo.copy();bpt=lo.copy();bpt[2]=hi[2]
            d.dim(xy(a),xy(bpt),left+10,fmt(hi[2]-lo[2]),True)
            for o in obs:d.balloon(xy(o['center']),positions[o['handle']])
            # Module chain with actual horizontal boundaries.
            coords=sorted({round(o[k][u],1) for o in obs for k in ('lo','hi')})
            for x1,x2 in zip(coords,coords[1:]):
                a=lo.copy();a[u]=x1;a[2]=hi[2];bpt=a.copy();bpt[u]=x2
                if x2-x1>100:d.dim(xy(a),xy(bpt),464,fmt(x2-x1))
            widest=max(o['dims'][u] for o in obs)
            chain=[o for o in obs if abs(o['dims'][u]-widest)<.15]
            zs=[]
            for z in sorted([min(o['lo'][2] for o in obs)]+[o[k][2] for o in chain for k in ('lo','hi')]):
                if not zs or z-zs[-1]>.15:zs.append(z)
            for z1,z2 in zip(zs,zs[1:]):
                if z2-z1<100:continue
                a=hi.copy();a[2]=z1;bpt=hi.copy();bpt[2]=z2
                d.dim(xy(a),xy(bpt),left+342,fmt(z2-z1),True)
            d.text(left,83,'Поз. в кружках - строки спецификации. Глубина модулей 120 мм.',7.5)
        d.end()
    if not walls:
        for label,U,D in [('Вид спереди',[1,0,0],[0,-1,0]),('Вид слева',[0,1,0],[-1,0,0])]:
            d.start(label+' - сборка');xy,b,scale=d.view(objects,U,[0,0,1],D,(90,108,650,370))
            u=0 if U[0] else 1;lo=allv.min(0);hi=allv.max(0)
            a=lo.copy();bpt=hi.copy();a[2]=bpt[2]=lo[2]
            d.dim(xy(a),xy(bpt),85,fmt(hi[u]-lo[u]));a=lo.copy();bpt=lo.copy();bpt[2]=hi[2]
            d.dim(xy(a),xy(bpt),65,fmt(hi[2]-lo[2]),True)
            d.text(45,76,'Отдельные стены автоматически не распознаны. Показан общий ортогональный вид.',9);d.end()
    d.start('Монтажные размеры и границы комплекта')
    y=489
    notes=['Основание модели: 5000х5000 мм.' if abs(np.ptp(allv[:,0])-5000)<1 and abs(np.ptp(allv[:,1])-5000)<1 else 'Габариты сборки: '+'х'.join(fmt(x) for x in np.ptp(allv,axis=0))+' мм.',
           'Высота конструкции по модели: '+fmt(np.ptp(allv[:,2]))+' мм.',
           'Стандартные модули объединены по полной форме с учётом поворота.',
           'Каждый экземпляр учитывается отдельно; детали внутри модуля не суммируются как короба.',
           'Доборные изделия учтены по исходным объектам; разделение на панели не предполагается.',
           'Размеры показаны с точностью 0,1 мм; численные значения не заменяют проверку посадок.',
           'Крепёж, соединения, материал и порядок монтажа не определяются однозначно по геометрии.',
           'Этот комплект не включает электросхему, кабельные трассы и назначения профилей.',
           'Перед производством и монтажом требуется согласовать недостающие узлы и материалы.']
    for i,text in enumerate(notes,1):d.text(44,y,f'{i}. {text}',11);y-=32
    # Find the narrow opening formed by actual 170 mm posts.
    posts=[o for o in objects if sorted(round(x) for x in o['dims'])==[120,170,2040]]
    if len(posts)==2:
        axis=int(np.argmax(np.abs(posts[0]['center']-posts[1]['center'])))
        a,b=sorted(posts,key=lambda o:o['center'][axis]);gap=b['lo'][axis]-a['hi'][axis]
        d.text(44,150,'Проход между стойками: '+fmt(gap)+' мм в свету; высота стоек 2040 мм.',12,True)
    d.end();d.c.save()
    manifest={'title':title,'sourceSha256':sourcehash,'pages':d.page,'objects':len(objects),'wallCount':len(walls),'positions':[{'position':p,'label':label,'count':count} for p,label,count in rows],'electricalIncluded':False,'requiresReview':True}
    out.with_suffix('.report.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');p.add_argument('title');args=p.parse_args()
    print(json.dumps(generate(args.source,args.output,args.title),ensure_ascii=False))
